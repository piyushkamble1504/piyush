const express = require('express');
const router = express.Router();
const {
    getAllBooks,
    getBookByISBN,
    getBooksByAuthor,
    getBooksByTitle,
    getBookReviews,
    addBookReview,
    updateBookReview,
    deleteBookReview,
    registerUser,
    loginUser
} = require('./controllers');
const { protect } = require('./middleware');

// Book routes
router.get('/books', getAllBooks);
router.get('/books/isbn/:isbn', getBookByISBN);
router.get('/books/author/:author', getBooksByAuthor);
router.get('/books/title/:title', getBooksByTitle);

// Review routes
router.get('/books/:bookId/reviews', getBookReviews);
router.post('/books/:bookId/reviews', protect, addBookReview);
router.put('/books/:bookId/reviews/:reviewId', protect, updateBookReview);
router.delete('/books/:bookId/reviews/:reviewId', protect, deleteBookReview);

// User routes
router.post('/users/register', registerUser);
router.post('/users/login', loginUser);

module.exports = router;
