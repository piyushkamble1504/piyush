const Book = require('./models/Book');
const User = require('./models/User');
const Review = require('./models/Review');
const jwt = require('jsonwebtoken');

// Generate JWT
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d',
    });
};

// Book Controllers
const getAllBooks = async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getBookByISBN = async (req, res) => {
    try {
        const book = await Book.findOne({ isbn: req.params.isbn });
        if (!book) {
            return res.status(404).json({ message: 'Book not found' });
        }
        res.json(book);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getBooksByAuthor = async (req, res) => {
    try {
        const books = await Book.find({ author: req.params.author });
        res.json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getBooksByTitle = async (req, res) => {
    try {
        const books = await Book.find({ title: { $regex: req.params.title, $options: 'i' } });
        res.json(books);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Review Controllers
const getBookReviews = async (req, res) => {
    try {
        const reviews = await Review.find({ book: req.params.bookId })
            .populate('user', 'username')
            .populate('book', 'title');
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const addBookReview = async (req, res) => {
    try {
        const review = new Review({
            book: req.params.bookId,
            user: req.user._id,
            rating: req.body.rating,
            comment: req.body.comment
        });
        const newReview = await review.save();
        res.status(201).json(newReview);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

const updateBookReview = async (req, res) => {
    try {
        const review = await Review.findOne({
            _id: req.params.reviewId,
            user: req.user._id
        });
        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }
        review.rating = req.body.rating || review.rating;
        review.comment = req.body.comment || review.comment;
        const updatedReview = await review.save();
        res.json(updatedReview);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

const deleteBookReview = async (req, res) => {
    try {
        const review = await Review.findOneAndDelete({
            _id: req.params.reviewId,
            user: req.user._id
        });
        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }
        res.json({ message: 'Review deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// User Controllers
const registerUser = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }
        const user = await User.create({
            username,
            email,
            password
        });
        res.status(201).json({
            _id: user._id,
            username: user.username,
            email: user.email,
            token: generateToken(user._id)
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        if (user && (await user.matchPassword(password))) {
            res.json({
                _id: user._id,
                username: user.username,
                email: user.email,
                token: generateToken(user._id)
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

module.exports = {
    getAllBooks,
    getBookByISBN,
    getBooksByAuthor,
    getBooksByTitle,
    getBookReviews,
    addBookReview,
    updateBookReview,
    deleteBookReview,
    registerUser,
    loginUser
};
