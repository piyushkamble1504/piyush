const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
    isbn: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    published_date: {
        type: Date
    },
    publisher: String,
    num_pages: Number,
    description: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Book', bookSchema); 